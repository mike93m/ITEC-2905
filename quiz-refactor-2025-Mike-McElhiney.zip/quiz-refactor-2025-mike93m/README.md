# Quiz program in need of improvement

Please see instructions in D2L. Also refer to this repository's issues https://github.com/claraj/quiz/issues

For testing, here are some extra questions. You may, of course, replace these with other questions of your choice. 

### Some extra art questions,
**Q:** Which kid's TV characters are named after Renaissance artists? **A:** Teenage Mutant Ninja Turtles  
**Q:** The graphite in an artist's pencil is made of what chemical element? **A:** Carbon  

### Here are some extra space questions,
**Q:** What was the first human-made object to leave the solar system? **A:** Voyager 1  
**Q:** When an asteroid enters the Earth's atmosphere and burns up, it is known as what? **A:** Meteor  

### Another topic - sport questions

**Q:** Which gymnast is the "triple-twisting double-tucked salto backwards" skill named after? **A:** Simone Biles  
**Q:** Which country has won the soccer world cup the most times? **A:** Brazil  
**Q:** What does MLB stand for? **A:** Major League Baseball  
