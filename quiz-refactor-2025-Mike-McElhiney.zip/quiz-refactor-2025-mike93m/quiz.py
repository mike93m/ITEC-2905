""" This quiz program allows the user to select a quiz topic and answer questions related to that topic.
    The topics, questions and answers are stored in a dictionary format.
    The run_quiz function takes user input for the topic and manages the quiz flow.
    Created by Clara James, updated by Mike McElhiney 08/2025."""

# Main function
# Gets the questions and answers from the dictionary based on the topic the user chose and keeps track of the score 
def run_quiz(topic) :
    total_score = 0 # Initialize the score
    # Loop through each question/answer in the quiz_questions dictionary for the selected topic
    for item in quiz_questions[topic] :
        # Display the question
        question = item['question'] 
        print(question)
        # Get the user's answer
        answer = normalize_string(input('Enter your answer: '))
        if answer == normalize_string(item['answer']): # Check if the answer is correct
            print('Correct!')
            total_score += 1 # Increment score if correct
        else: # Display the correct answer if wrong
            print(f'Sorry, "{answer}" is incorrect. The correct answer is {item["answer"]}.')

    print('End of quiz!')

    # Display the total score based on the length of the quiz_questions list for the selected topic
    print(f'Your total score on {topic} questions is {total_score} out of {len(quiz_questions[topic])}.')

    # If the total score is the same as the total number of questions or less than 2, display a special message
    if total_score == len(quiz_questions[topic]):
        print('You got all the answers correct!')
    elif total_score <= 1:
        print('Better luck next time!')
    return total_score

# Function to normalize strings for comparison
def normalize_string(string):
    return string.strip().lower().replace(" ", "")

# Quiz questions dictionary
# The topic is the key and the value is a list which contains the questions and answers in dictionary format
quiz_questions = {
    'art': [ 
        {
            'question': 'Who painted the Mona Lisa?',
            'answer': 'Leonardo Da Vinci'
        },
        {
            'question': 'What precious stone is used to make the artist\'s pigment ultramarine?',
            'answer': 'Lapiz lazuli'
        },
        {
            'question': 'Anish Kapoor\'s bean-shaped Cloud Gate sculpture is a landmark of which city?',
            'answer': 'Chicago'
        },
        {
            'question': 'Which kid\'s TV characters are named after Renaissance artists?',
            'answer': 'Teenage Mutant Ninja Turtles'
        },
        {
            'question': 'The graphite in an artist\'s pencil is made of what chemical element?',
            'answer': 'Carbon'
        }
    ],
    'space': [
        {
            'question': 'Which planet is closest to the sun?',
            'answer': 'Mercury'
        },
        {
            'question': 'Which planet spins in the opposite direction to all the others in the solar system?',
            'answer': 'Venus'
        },
        {
            'question': 'How many moons does Mars have?',
            'answer': '2'
        },
        {
            'question': 'What was the first human-made object to leave the solar system?',
            'answer': 'Voyager 1'
        },
        {
            'question': 'When an asteroid enters the Earth\'s atmosphere and burns up, it is known as what?',
            'answer': 'Meteor'
        }
    ],
    'sports': [
        {
            'question': 'Which gymnast is the "triple-twisting double-tucked salto backwards" skill named after?',
            'answer': 'Simone Biles'
        },
        {
            'question': 'Which country has won the soccer world cup the most times?',
            'answer': 'Brazil'
        },
        {
            'question': 'What does MLB stand for?',
            'answer': 'Major League Baseball'
        }
    ]
}

# Welcome message
print('Welcome to the quiz program!\n'
      'Select a topic and the program will keep score for you!')

while True:
    # Get the user's chosen topic
    topic = normalize_string(input('Choose a topic (art, space or sports): '))
    # If the topic exists in the quiz_questions dictionary call the run_quiz function
    if topic in quiz_questions:
        run_quiz(topic)
        # Ask the user if they want to play again
        play_again = normalize_string(input('Would you like to play again? (yes or no): '))
        if play_again == 'no' or play_again == 'n':
            print('Exiting the program. Goodbye!')
            exit()
        else:
            continue
    # If the user types 'esc' or 'escape', exit the program
    if topic == 'esc' or topic == 'escape':
        print('Exiting the program. Goodbye!')
        exit()
    else:
        # If the topic is not valid, display an error message
        print('That is not a valid topic. Please type a valid topic or "esc" or "escape" to exit.')

    
