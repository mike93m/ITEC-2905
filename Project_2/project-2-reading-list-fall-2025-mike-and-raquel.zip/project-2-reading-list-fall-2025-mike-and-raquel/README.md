# Book Reading List

Program description
Basic python book reading list application. For practicing teamwork and GitHub collaboration. 
This is a small, menu-driven command-line application for keeping a personal reading list. You can add books you want to read, mark them as read or not read, search by title or author (case-insensitive, partial matches), and list books by status or see all of them. Data is stored persistently in a local SQLite database located under the database/ folder.

Key features
- Add a book with title and author
- Prevent duplicate entries of the same title+author (case-insensitive)
- Mark a book as read or not read and update later
- Search books by partial title or author, case-insensitive
- List unread books, read books, or all books
- Simple, testable design with unit tests

How it works (architecture)
- Data model: A Book has title (text), author (text), read (boolean), and id (rowid assigned by SQLite after save).
- Persistence: SQLite database file at database/books.db. A unique constraint on title+author (both case-insensitive) prevents duplicates.
- Store: BookStore is a singleton wrapper that encapsulates all database operations (create, update, delete, queries). Book.save() delegates to BookStore to add or update.
- CLI: main.py constructs a Menu of options and uses ui.py to handle user interaction (printing, inputs, simple validation).

Menu options
1. Add Book
2. Search For Book
3. Show Unread Books
4. Show Read Books
5. Show All Books
6. Change Book Read Status
Q. Quit

Typical workflow
- Add Book: Enter title and author. The book is saved as unread by default.
- Change Read Status: Enter a book id, then indicate read/not read. The record is updated.
- Search: Enter any text; matches titles or authors that contain the text, ignoring case.
- Show lists: Display books by status or all books.

Requirements
- Python 3.7+ (tested with 3.7 and later)
- SQLite (bundled with Python via sqlite3 module)

Setup and running
- Optional: create and activate a virtual environment.
- Install nothing extra; the standard library is sufficient.
- Run the program: python main.py
- The app will create database/books.db on first run (if it does not exist) and ensure the books table is created.

Data location
- Production database: database/books.db
- Tests use a separate file: database/test_books.db (set by tests)

Testing
- The project includes unit tests for the core components (Book, BookStore, Menu, UI).
- To run tests with pytest (if you have it installed): pytest
- Alternatively, run with the built-in unittest runner: python -m unittest

Project structure (high-level)
- main.py: Program entry point and menu actions
- ui.py: Console I/O helpers (prompting, printing, simple validation)
- menu.py: Menu abstraction (options, validation, dispatch)
- bookstore.py: Book model and BookStore singleton with SQLite persistence
- database/: Holds the SQLite database files
- test/: Unit tests for the above modules

Notes and limitations
- Duplicate detection is based on exact title+author (case-insensitive). Different editions or similar titles by different authors are treated as distinct.
- The read flag is stored as a boolean (SQLite stores as 0/1). There is no timestamp/history of changes.
- No concurrent access control; this is a simple single-user CLI tool.
- There is minimal input validation; IDs must be positive integers.

Troubleshooting
- If you encounter a duplicate error when adding a book, the title and author combination already exists (ignoring letter case).
- If Change Book Read Status cannot find an id, ensure you typed a positive integer and that the book exists. Use Show All Books to see ids.


Authors: 
 - Mike McElhiney
 - Raquel Velis